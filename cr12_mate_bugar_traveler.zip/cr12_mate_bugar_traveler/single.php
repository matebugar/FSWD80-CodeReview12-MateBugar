<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package cr12_mate_bugar
 */

get_header();
?>
<div class="fluid-container">
<div class="row">

<div class="col-lg-8">
	<div class="card-group">

<?php if ( have_posts() ) :?>

<?php 
while(have_posts()) : the_post();
?>
<div class="col-lg-12 col-md-12 col-sm-12 ">
          <div class="card h-100 ">
            
            <div class="card-body ">
              <h4 class="card-title">
                <a class="title" href="<?php the_permalink() ?>"><h2><?php the_title(); ?></h2></a>
              </h4>
              <p class="card-text"><?php the_content()?></p>
              
              <?php comments_template(); ?>
            </div>
          </div>
        </div>
<?php
			endwhile;

			the_posts_navigation();

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>

	
	</div><!-- #primary -->
</div>
<div class="col-lg-3 sideBar">
<?php
get_sidebar();
?>
</div>
</div>
</div>

<?php
get_footer();
?>